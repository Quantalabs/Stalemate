from tkinter import *
from . import draw

__version__ = '0.0.1'
